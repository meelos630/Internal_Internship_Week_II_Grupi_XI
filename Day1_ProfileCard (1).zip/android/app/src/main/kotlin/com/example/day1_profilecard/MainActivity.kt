package com.example.day1_profilecard

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
