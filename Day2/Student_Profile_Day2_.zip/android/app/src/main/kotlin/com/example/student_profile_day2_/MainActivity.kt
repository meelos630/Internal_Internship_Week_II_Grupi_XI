package com.example.student_profile_day2_

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
