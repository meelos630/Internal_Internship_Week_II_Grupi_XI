import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Day 2 App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const StudentScreen(),
    );
  }
}

class StudentScreen extends StatefulWidget {
  const StudentScreen({super.key});

  @override
  State<StudentScreen> createState() => _StudentScreenState();
}

class _StudentScreenState extends State<StudentScreen> {
  final nameController = TextEditingController();
  final emailController = TextEditingController();

  List<Map<String, String>> students = [];

  String errorMessage = '';

  bool isValidEmail(String email) {
    return email.contains('@') && email.contains('.');
  }

  void addStudent() {
    final name = nameController.text.trim();
    final email = emailController.text.trim();

    setState(() {
      errorMessage = '';

      if (name.isEmpty || email.isEmpty) {
        errorMessage = 'Plotëso të gjitha fushat!';
        return;
      }

      if (!isValidEmail(email)) {
        errorMessage = 'Email nuk është valid!';
        return;
      }

      students.add({
        'name': name,
        'email': email,
      });

      nameController.clear();
      emailController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Student List'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // FORM
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Emri',
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 10),

            TextField(
              controller: emailController,
              decoration: const InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 10),

            if (errorMessage.isNotEmpty)
              Text(
                errorMessage,
                style: const TextStyle(color: Colors.red),
              ),

            const SizedBox(height: 10),

            ElevatedButton(
              onPressed: addStudent,
              child: const Text('Shto Student'),
            ),

            const SizedBox(height: 20),

            // LISTA
            Expanded(
              child: students.isEmpty
                  ? const Center(child: Text('Nuk ka studentë'))
                  : ListView.builder(
                      itemCount: students.length,
                      itemBuilder: (context, index) {
                        final student = students[index];

                        return Card(
                          child: ListTile(
                            title: Text(student['name']!),
                            subtitle: Text(student['email']!),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
