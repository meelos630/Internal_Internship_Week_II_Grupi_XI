# Day 5 Task Manager App

This is the final project for Internal Internship Day 5. It is a small Flutter Task Manager MVP that combines the topics from Day 1 to Day 4 into one usable app.

## Project Idea

The app helps a user manage internship tasks. The user can view tasks, create a new task, open task details, edit a task, delete a task, and mark tasks as complete.

## MVP Features

1. Task list with loading, empty, error, and success states.
2. Add and edit form with validation for title and description.
3. Details screen with full task information, complete toggle, edit, and delete.

## Concepts Used From Day 1-4

- Day 1: `main()`, `runApp`, `MaterialApp`, `Scaffold`, `Text`, `Icon`, `Row`, `Column`, buttons, and layout basics.
- Day 2: `StatefulWidget`, forms, `TextEditingController`, validation, cards, spacing, and readable UI.
- Day 3: `setState`, dynamic lists, model classes, navigation with `Navigator.push/pop`, `SnackBar`, and `AlertDialog`.
- Day 4: async methods with `Future`, loading/error/success UI states, JSON parsing with `fromJson` and `toJson`, and separating code into model, service, and screens.

## Folder Structure

```text
lib/
  main.dart
  models/
    task.dart
  screens/
    task_list_screen.dart
    task_form_screen.dart
    task_detail_screen.dart
  services/
    task_service.dart
```

## How To Run In FlutLab Or Replit

1. Create or open a Flutter project in FlutLab or Replit.
2. Copy this project folder into the Flutter workspace, or copy the `lib` folder and `pubspec.yaml` into the template project.
3. Run `flutter pub get`.
4. Start the app with the run button or `flutter run`.

## Demo Script

Use this flow for a 2-3 minute demo:

1. Open the app and show the loading state, then the starter task list.
2. Explain that the starter tasks come from local JSON-like seed data in `TaskService`.
3. Tap **Add task**, leave a required field empty, and show validation.
4. Add a valid task and show that the list updates.
5. Open a task details screen and show priority, due date, status, and description.
6. Mark the task complete, then edit it.
7. Delete a task and confirm the list updates.
8. Mention that the app is separated into model, service, and UI screens.

## Screenshots

Add screenshots here after running the app:

- Home screen with task list.
- Add/edit task form.
- Task details screen.

## What Works

- Loads starter tasks asynchronously.
- Displays open and completed task counts.
- Adds tasks with validation.
- Edits tasks.
- Deletes tasks after confirmation.
- Toggles complete/open status.
- Uses model and service files to keep the code organized.

## Future Improvements

- Save tasks permanently with local storage.
- Connect the service to a real API or Cloudflare D1 backend.
- Add search and filters by status or priority.
- Add screenshots to the README after running the app.
- Add automated widget tests.
