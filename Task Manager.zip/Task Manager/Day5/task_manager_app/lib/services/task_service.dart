import '../models/task.dart';

class TaskService {
  final List<Task> _tasks = [];
  bool _hasLoadedSeedData = false;

  Future<List<Task>> loadTasks() async {
    await Future<void>.delayed(const Duration(milliseconds: 650));

    if (!_hasLoadedSeedData) {
      _tasks
        ..clear()
        ..addAll(_seedData.map(Task.fromJson));
      _hasLoadedSeedData = true;
    }

    return _sortedTasks();
  }

  Future<Task> addTask({
    required String title,
    required String description,
    required TaskPriority priority,
    required DateTime dueDate,
  }) async {
    await Future<void>.delayed(const Duration(milliseconds: 250));

    final task = Task(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      title: title,
      description: description,
      priority: priority,
      dueDate: dueDate,
      isDone: false,
    );

    _tasks.add(task);
    return task;
  }

  Future<Task> updateTask(Task task) async {
    await Future<void>.delayed(const Duration(milliseconds: 250));

    final index = _tasks.indexWhere((item) => item.id == task.id);
    if (index == -1) {
      throw StateError('Task not found.');
    }

    _tasks[index] = task;
    return task;
  }

  Future<void> deleteTask(String id) async {
    await Future<void>.delayed(const Duration(milliseconds: 250));

    final taskCountBeforeDelete = _tasks.length;
    _tasks.removeWhere((task) => task.id == id);

    if (_tasks.length == taskCountBeforeDelete) {
      throw StateError('Task not found.');
    }
  }

  Future<Task> toggleTask(String id) async {
    await Future<void>.delayed(const Duration(milliseconds: 200));

    final index = _tasks.indexWhere((task) => task.id == id);
    if (index == -1) {
      throw StateError('Task not found.');
    }

    final updated = _tasks[index].copyWith(isDone: !_tasks[index].isDone);
    _tasks[index] = updated;
    return updated;
  }

  List<Task> _sortedTasks() {
    final tasks = List<Task>.from(_tasks);
    tasks.sort((a, b) {
      if (a.isDone != b.isDone) {
        return a.isDone ? 1 : -1;
      }

      final dueDateComparison = a.dueDate.compareTo(b.dueDate);
      if (dueDateComparison != 0) {
        return dueDateComparison;
      }

      return _priorityWeight(a.priority).compareTo(_priorityWeight(b.priority));
    });
    return List<Task>.unmodifiable(tasks);
  }

  int _priorityWeight(TaskPriority priority) {
    switch (priority) {
      case TaskPriority.high:
        return 0;
      case TaskPriority.medium:
        return 1;
      case TaskPriority.low:
        return 2;
    }
  }
}

final List<Map<String, dynamic>> _seedData = [
  {
    'id': 'task-1',
    'title': 'Finish Flutter final MVP',
    'description': 'Build the list, form, details screen, and service layer.',
    'priority': 'high',
    'dueDate': '2026-06-19T17:00:00.000',
    'isDone': false,
  },
  {
    'id': 'task-2',
    'title': 'Prepare 2 minute demo',
    'description': 'Explain Day 1-4 concepts and show add, edit, delete, and complete.',
    'priority': 'medium',
    'dueDate': '2026-06-19T18:00:00.000',
    'isDone': false,
  },
  {
    'id': 'task-3',
    'title': 'Write README reflection',
    'description': 'Document what works now and what could be improved next.',
    'priority': 'low',
    'dueDate': '2026-06-20T12:00:00.000',
    'isDone': true,
  },
];
