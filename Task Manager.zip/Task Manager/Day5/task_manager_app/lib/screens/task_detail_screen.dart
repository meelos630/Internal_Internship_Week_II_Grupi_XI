import 'package:flutter/material.dart';

import '../models/task.dart';
import '../services/task_service.dart';
import 'task_form_screen.dart';

class TaskDetailScreen extends StatefulWidget {
  const TaskDetailScreen({
    required this.task,
    required this.service,
    super.key,
  });

  final Task task;
  final TaskService service;

  @override
  State<TaskDetailScreen> createState() => _TaskDetailScreenState();
}

class _TaskDetailScreenState extends State<TaskDetailScreen> {
  late Task _task;
  bool _hasChanged = false;
  bool _isUpdating = false;

  @override
  void initState() {
    super.initState();
    _task = widget.task;
  }

  Future<bool> _leaveScreen() async {
    Navigator.pop(context, _hasChanged);
    return false;
  }

  Future<void> _toggleComplete() async {
    setState(() {
      _isUpdating = true;
    });

    try {
      final updatedTask = await widget.service.toggleTask(_task.id);
      if (!mounted) return;

      setState(() {
        _task = updatedTask;
        _hasChanged = true;
        _isUpdating = false;
      });

      _showMessage(_task.isDone ? 'Task completed.' : 'Task reopened.');
    } catch (error) {
      if (!mounted) return;

      setState(() {
        _isUpdating = false;
      });
      _showMessage('Could not update task.');
    }
  }

  Future<void> _editTask() async {
    final updatedTask = await Navigator.push<Task?>(
      context,
      MaterialPageRoute(
        builder: (_) => TaskFormScreen(
          service: widget.service,
          task: _task,
        ),
      ),
    );

    if (updatedTask == null || !mounted) return;

    setState(() {
      _task = updatedTask;
      _hasChanged = true;
    });
    _showMessage('Task updated.');
  }

  Future<void> _confirmDelete() async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete task?'),
        content: const Text('This action removes the task from the list.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton.icon(
            onPressed: () => Navigator.pop(context, true),
            icon: const Icon(Icons.delete),
            label: const Text('Delete'),
          ),
        ],
      ),
    );

    if (shouldDelete != true) return;

    try {
      await widget.service.deleteTask(_task.id);
      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (error) {
      if (!mounted) return;
      _showMessage('Could not delete task.');
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _leaveScreen,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Task details'),
          leading: IconButton(
            tooltip: 'Back',
            onPressed: _leaveScreen,
            icon: const Icon(Icons.arrow_back),
          ),
          actions: [
            IconButton(
              tooltip: 'Edit task',
              onPressed: _editTask,
              icon: const Icon(Icons.edit),
            ),
            IconButton(
              tooltip: 'Delete task',
              onPressed: _confirmDelete,
              icon: const Icon(Icons.delete_outline),
            ),
          ],
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                color: Colors.white,
                elevation: 1,
                margin: EdgeInsets.zero,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          _DetailChip(
                            icon: Icons.flag,
                            label: _task.priority.label,
                            color: _priorityColor(_task.priority),
                          ),
                          _DetailChip(
                            icon: _task.isDone
                                ? Icons.check_circle
                                : Icons.radio_button_unchecked,
                            label: _task.isDone ? 'Done' : 'Open',
                            color: _task.isDone ? Colors.green : Colors.orange,
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        _task.title,
                        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                              fontWeight: FontWeight.w800,
                            ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        _task.description,
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                      const SizedBox(height: 20),
                      Row(
                        children: [
                          Icon(
                            Icons.calendar_month,
                            color: Theme.of(context).colorScheme.primary,
                          ),
                          const SizedBox(width: 10),
                          Text(
                            'Due ${_formatDate(_task.dueDate)}',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: _isUpdating ? null : _toggleComplete,
                icon: _isUpdating
                    ? const SizedBox.square(
                        dimension: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : Icon(_task.isDone ? Icons.undo : Icons.check),
                label: Text(_task.isDone ? 'Mark as open' : 'Mark as complete'),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: _editTask,
                icon: const Icon(Icons.edit),
                label: const Text('Edit task'),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: _confirmDelete,
                icon: const Icon(Icons.delete_outline),
                label: const Text('Delete task'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DetailChip extends StatelessWidget {
  const _DetailChip({
    required this.icon,
    required this.label,
    required this.color,
  });

  final IconData icon;
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 6),
          Text(
            label,
            style: Theme.of(context).textTheme.labelMedium?.copyWith(
                  color: color,
                  fontWeight: FontWeight.w700,
                ),
          ),
        ],
      ),
    );
  }
}

Color _priorityColor(TaskPriority priority) {
  switch (priority) {
    case TaskPriority.high:
      return Colors.red;
    case TaskPriority.medium:
      return Colors.deepOrange;
    case TaskPriority.low:
      return Colors.teal;
  }
}

String _formatDate(DateTime date) {
  final localDate = date.toLocal();
  final day = localDate.day.toString().padLeft(2, '0');
  final month = localDate.month.toString().padLeft(2, '0');
  return '$day/$month/${localDate.year}';
}
