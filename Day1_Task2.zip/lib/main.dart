import 'package:flutter/material.dart';

void main() {
  runApp(GradeApp());
}

class GradeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: GradeCalculator(),
    );
  }
}

class GradeCalculator extends StatefulWidget {
  @override
  _GradeCalculatorState createState() => _GradeCalculatorState();
}

class _GradeCalculatorState extends State<GradeCalculator> {
  final TextEditingController grade1Controller = TextEditingController();
  final TextEditingController grade2Controller = TextEditingController();
  final TextEditingController grade3Controller = TextEditingController();

  String result = "";
  String status = "";

  void calculateAverage() {
    String g1 = grade1Controller.text;
    String g2 = grade2Controller.text;
    String g3 = grade3Controller.text;

    if (g1.isEmpty || g2.isEmpty || g3.isEmpty) {
      setState(() {
        result = "Ju lutem plotësoni të gjitha fushat!";
        status = "";
      });
      return;
    }

    double? n1 = double.tryParse(g1);
    double? n2 = double.tryParse(g2);
    double? n3 = double.tryParse(g3);

    if (n1 == null || n2 == null || n3 == null) {
      setState(() {
        result = "Vendosni vetëm numra!";
        status = "";
      });
      return;
    }

    double average = (n1 + n2 + n3) / 3;

    setState(() {
      result = "Mesatarja: ${average.toStringAsFixed(2)}";

      if (average >= 2.5) {
        status = "Status: Kalon ✅";
      } else {
        status = "Status: Duhet përmirësim ❌";
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Grade Calculator"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: grade1Controller,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: "Nota 1"),
            ),
            TextField(
              controller: grade2Controller,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: "Nota 2"),
            ),
            TextField(
              controller: grade3Controller,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: "Nota 3"),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: calculateAverage,
              child: Text("Calculate"),
            ),
            SizedBox(height: 20),
            Text(result, style: TextStyle(fontSize: 18)),
            Text(status, style: TextStyle(fontSize: 18)),
          ],
        ),
      ),
    );
  }
}
