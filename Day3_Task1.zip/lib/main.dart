import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: QuizScreen(),
    );
  }
}

// ================= MODEL CLASS =================

class Question {
  final String questionText;
  final List<String> options;
  final int correctIndex;

  Question({
    required this.questionText,
    required this.options,
    required this.correctIndex,
  });
}

// ================= QUIZ SCREEN =================

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int currentQuestion = 0;
  int score = 0;

  List<Question> questions = [
    Question(
      questionText: "What is Flutter?",
      options: ["Framework", "Language", "Database", "OS"],
      correctIndex: 0,
    ),
    Question(
      questionText: "Who created Flutter?",
      options: ["Apple", "Google", "Microsoft", "Meta"],
      correctIndex: 1,
    ),
    Question(
      questionText: "Which language is used in Flutter?",
      options: ["Java", "Dart", "Python", "C#"],
      correctIndex: 1,
    ),
    Question(
      questionText: "What does setState do?",
      options: ["Update UI", "Delete data", "Navigate", "Debug"],
      correctIndex: 0,
    ),
    Question(
      questionText: "Navigator is used for?",
      options: ["Design", "Routing", "Storage", "Testing"],
      correctIndex: 1,
    ),
  ];

  void answerQuestion(int selectedIndex) {
    if (selectedIndex == questions[currentQuestion].correctIndex) {
      score++;
    }

    if (currentQuestion < questions.length - 1) {
      setState(() {
        currentQuestion++;
      });
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ResultScreen(score: score),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    var q = questions[currentQuestion];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Quiz App"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              "Question ${currentQuestion + 1}/${questions.length}",
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 10),
            Text(
              q.questionText,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            ...List.generate(q.options.length, (index) {
              return Container(
                margin: const EdgeInsets.only(bottom: 10),
                child: ElevatedButton(
                  onPressed: () => answerQuestion(index),
                  child: Text(q.options[index]),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}

// ================= RESULT SCREEN =================

class ResultScreen extends StatelessWidget {
  final int score;

  const ResultScreen({super.key, required this.score});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Result"),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Your Score: $score",
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text("Restart Quiz"),
            )
          ],
        ),
      ),
    );
  }
}
